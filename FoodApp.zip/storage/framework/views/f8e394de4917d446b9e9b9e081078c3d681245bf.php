<?php $__env->startSection('title', 'delivery'); ?>


<?php $__env->startSection('content'); ?>

	<div class="container">

		<div class="row">

			<!-- div lateral Categorias -->
			<div class="col-sm-3">

				<div class="panel panel-default">
				  	<div class="panel-heading">
				    	<h3 class="panel-title">Categorias</h3>
				  	</div>
				  	<div class="panel-body">
				  	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    	<a href="<?php echo e(route('user.category.show', $category->id)); ?>"><?php echo e($category->name); ?></a><br>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  	</div>
				</div>

				<div class="panel panel-default">
				  	<div class="panel-heading">
				    	<h3 class="panel-title">Ciudades</h3>
				  	</div>
				  	<div class="panel-body">
				  	<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    	<a href="l/<?php echo e($city->city); ?>"><?php echo e($city->city); ?></a><br>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  	</div>
				</div>		
				
			</div>

			<!-- div central -->


			
			<div class="col-sm-9">

				<div class="row">
					<div class="panel panel-default">
					  	<div class="panel-heading">
					    	<h1 class="panel-title">Información:</h1>
					  	</div>
					  	<div class="panel-body">
					  		<center><h2 class="page-header"><?php echo e($delivery->name); ?></h2></center>
					  		<div class="col-sm-12">
							<center><img class="img-thumbnail" src="<?php echo e($delivery->logo); ?>" width="80%"></center><br>
						</div>
						<div class="col-sm-6"><p class="text-justify lead"><?php echo e($delivery->short); ?></p></div>
						<div class="col-sm-6">
							<div class="well">
								<p class="text-right"><i class="fa fa-map-marker" aria-hidden="true"></i>  Ciudad: <?php echo e($delivery->city); ?></p>
								<p class="text-right"><i class="fa fa-map-signs" aria-hidden="true"></i>  Comuna: <?php echo e($delivery->commune); ?></p>
								<p class="text-right"><i class="fa fa-phone" aria-hidden="true"></i>  Telefono: <?php echo e($delivery->phone); ?></p>
								<p class="text-right"><i class="fa fa-truck" aria-hidden="true"></i>  Sector de reparto: <?php echo e($delivery->sector); ?></p>
							</div>
						</div>
						<div class="col-sm-12">
							<p class="lead text-justify"><strong><?php echo e($delivery->body); ?></strong></p>
						</div>
					</div>	
				</div>

				<?php if(count($promotions) > 0): ?>
				<div class="panel panel-default">
				  	<div class="panel-heading">
				    	<h3 class="panel-title">Promociones</h3>
				  	</div>
				  	<div class="panel-body">

				    	<table class="table table-striped">
				    		<thead>
				    			<th width="200px">Imagen</th>
				    			<th>Descripción</th>
				    			<th>Precio</th>
				    		</thead>
				    		<tbody>
				    			<?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    			<tr>
				    				<td><center><img class="img-thumbnail" src="<?php echo e($promotion->photo); ?>" alt="<?php echo e($promotion->title); ?>" width="85%"></center></td>
				    				<td><p><strong><?php echo e($promotion->title); ?></strong>  <bR> <?php echo e($promotion->description); ?></p></td>
				    				<td>$<?php echo e($promotion->price); ?></td>
				    			</tr>
				    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    		</tbody>
				    	</table>
				    
				    
				  	</div>
				</div>
				<?php endif; ?>
				
				<?php if(count($comments) > 0): ?>
				<div class="panel panel-default">
				  	<div class="panel-heading">
				    	<h3 class="panel-title">Comentarios</h3>
				  	</div>
				  	<div class="panel-body">

				  	<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    	<blockquote class="blockquote-reverse">
  							<p>"<?php echo e($comment->comment); ?>"</p>
  							<h6>- <?php echo e($comment->user->name); ?></h6>
  								<h6><p class="text-right">Puntaje <?php echo e($comment->score); ?>/5</p></h6>
						</blockquote>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    
				  	</div>
				</div>
				<?php else: ?>

				<div class="panel panel-default">
				  	<div class="panel-heading">
				    	<h3 class="panel-title">Recomentaciones</h3>
				  	</div>
				  	<div class="panel-body">
					
						<p>Este Delivery aun no tiene Recomendaciones</p>	
						<br>
										  	
				  	</div>
				</div>

				<?php endif; ?>


				<?php if(Auth::user()): ?> <!-- Mostrar comentarios si el usuario esta logueado -->

				<div class="panel panel-default">
				  	<div class="panel-heading">
				    	<h3 class="panel-title">Dejar Recomendación</h3>
				  	</div>
					<div class="panel-body">
						<form action="<?php echo e(route('user.comment.store')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<div class="form-group">
								<p class="lead">Puntaje:</p>
								<div class="stars">
								    <input class="star star-5" id="star-5" type="radio" name="score" value="5" />
								    <label class="star star-5" for="star-5"></label>
								    <input class="star star-4" id="star-4" type="radio" name="score" value="4" />
								    <label class="star star-4" for="star-4"></label>
								    <input class="star star-3" id="star-3" type="radio" name="score" value="3" />
								    <label class="star star-3" for="star-3"></label>
								    <input class="star star-2" id="star-2" type="radio" name="score" value="2" />
								    <label class="star star-2" for="star-2"></label>
								    <input class="star star-1" id="star-1" type="radio" name="score" value="1" />
								    <label class="star star-1" for="star-1"></label>
								</div>
								<span>
									<input class="form-control" type="area" name="comment" width="100%" placeholder="Escriba su recomendación">
									<input type="hidden" value="<?php echo e($delivery->id); ?>" name="delivery">
								</span><br>
								<input class="form-control" type="submit" name="">
							</div>	
						</form>	
					</div>
				</div>

				<?php endif; ?>
				
			</div> <!-- col-sm-9 -->
		</div><!-- row -->
	</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>