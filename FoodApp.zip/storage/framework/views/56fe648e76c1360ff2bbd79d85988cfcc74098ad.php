<?php $__env->startSection('title','Create User'); ?>

<?php $__env->startSection('action','- Create User'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="col-sm-11">
		<a href="<?php echo e(route('admin.user.index')); ?>" class="btn  btn-info pull-right">Show List</a> <br><br><br>

		<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
		<?php echo Form::open(['route' => ['admin.user.store']]); ?>

	
		<div class="form-group">
			<?php echo Form::label('name', 'Nombre', ['class' => 'pull-left']); ?>

			<?php echo Form::text('name', null, [ 'class' => 'form-control', 'placeholder' => 'Nombre']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('email', 'E-mail', ['class' => 'pull-left']); ?>

			<?php echo Form::email('email', null, [ 'class' => 'form-control', 'placeholder' => 'Email@example.com']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('password', 'Contraseña', ['class' => 'pull-left']); ?>

			<?php echo Form::password('password', [ 'class' => 'form-control', 'placeholder' => '*********']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('premium', 'Dias Premium', ['class' => 'pull-left']); ?>

			<?php echo Form::number('premium', null, [ 'class' => 'form-control', 'placeholder' => '0']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('type', 'Acceso', ['class' => 'pull-left']); ?>

			<?php echo Form::select('type', ['MEMBER' => 'Miembro', 'ADMIN' => 'Administrador'], null, [ 'class' => 'form-control', 'placeholder' => 'Elija un tipo']); ?>	
		</div>
		
		<div class="form-group">
			<?php echo Form::submit('Enviar', [ 'class' => 'btn btn-primary']); ?>	
		</div>
	
		
		<?php echo Form::close(); ?>

	</div>
</div>			
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>