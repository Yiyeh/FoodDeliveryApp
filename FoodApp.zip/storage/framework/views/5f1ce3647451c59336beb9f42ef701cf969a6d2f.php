<?php $__env->startSection('title', 'delivery'); ?>


<?php $__env->startSection('content'); ?>

	<div class="container">

		<div class="row">

			<ol class="breadcrumb">
			  <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
			  <li class="active"><a href="<?php echo e(route('guest.delivery.list')); ?>">Deliveries</a></li>
			</ol>

			<!-- div lateral Categorías -->
			<?php echo $__env->make('layouts._categoryNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			
			<!-- div central -->			
			<div class="col-sm-9">
				
				<?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="panel panel-default">
				 
				  	<div class="panel-heading">
				    	<h3 class="panel-title">
				    		<?php echo e($delivery->name); ?>

				    		<a href="<?php echo e(route('guest.delivery.show', $delivery->id)); ?>" class="btn btn-xs btn-default pull-right" >Ver Delivery</a>
				    	</h3>

				  	</div>
				  	<div class="panel-body">
				    	<div class="col-sm-2">
			    			<img class="img-thumbnail" src="<?php echo e($delivery->logo); ?>" width="95%">
			    		</div>
			    		<div class="col-sm-7">
			    			<span><?php echo e($delivery->short); ?> </span>
			    		</div>
						<div class="col-sm-3">
			    		<span class="pull-right"> 	
			    			<i class="fa fa-truck" aria-hidden="true"></i>  <?php echo e($delivery->sector); ?> <br> 
			    			<i class="fa fa-map-marker" aria-hidden="true"></i>  <?php echo e($delivery->city); ?> <br> 
			    			<i class="fa fa-phone" aria-hidden="true"></i><small class="text-muted">  <?php echo e($delivery->phone); ?></small>
			    		</span>
			    			
			    		</div>			
				  	</div>			
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php echo $deliveries->render(); ?>

	
			</div> <!-- col-sm-9 -->
		</div><!-- row -->
	</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>