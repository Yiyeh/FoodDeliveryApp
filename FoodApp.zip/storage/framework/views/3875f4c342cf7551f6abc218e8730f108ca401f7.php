<?php $__env->startSection('title','Editar Delivery'); ?>

<?php $__env->startSection('action','- Editar Delivery'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="col-sm-11">
		<a href="<?php echo e(url('/mydelivery')); ?>" class="btn  btn-info pull-right">Ver mis deliveries</a> <br><br><br>

		<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
		<?php echo Form::model($delivery, ['route' => ['user.delivery.update', $delivery->id], 'method' => 'PUT' ]); ?>

	
		<div class="form-group">
			<?php echo Form::label('category', 'Categoria', ['class' => 'pull-left']); ?>

			<?php echo Form::select('category', $categories, null, [ 'class' => 'form-control', 'placeholder' => 'Elija una categoria']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('name', 'Nombre del Delivery', ['class' => 'pull-left']); ?>

			<?php echo Form::text('name', null, [ 'class' => 'form-control', 'placeholder' => 'Nombre']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('short', 'Descripción Breve', ['class' => 'pull-left']); ?>

			<?php echo Form::textarea('short', null,[ 'class' => 'form-control', 'placeholder' => 'Descripción Breve....']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('body', 'Descripción Detallada', ['class' => 'pull-left']); ?>

			<?php echo Form::textarea('body', null,[ 'class' => 'form-control', 'placeholder' => 'Descripción Detallada....']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('sector','Zona de reparto', ['class' => 'pull-left']); ?>

			<?php echo Form::text('sector', null, ['class' => 'form-control', 'placeholder' => 'Ejemplo: "Todo Iquique"']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('phone', 'Teléfono', ['class' => 'pull-left']); ?>

			<?php echo Form::text('phone', null, [ 'class' => 'form-control', 'placeholder' => 'Teléfono']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('logo', 'Logo', ['class' => 'pull-left']); ?>

			<?php echo Form::file('logo', null, [ 'class' => 'form-control']); ?>	
		</div><br>
		
		<div class="form-group">
			<?php echo Form::label('fbPage','Facebook Fanpage',['class' => 'pull-left']); ?>

			<?php echo Form::url('fbPage', null, ['class' => 'form-control', 'placeholder' => 'Ejemplo: http://facebook.com/mideliveryoficial']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('commune','Comuna', ['class' => 'pull-left']); ?>

			<?php echo Form::text('commune', null, ['class' => 'form-control', 'placeholder' => 'Comuna ( si pertenece a alguna )']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('city','Ciudad', ['class' => 'pull-left']); ?>

			<?php echo Form::text('city', null, ['class' => 'form-control', 'placeholder' => 'Ciudad']); ?>

		</div>


		<div class="form-group">
			<?php echo Form::label('published','Tipo', ['class' => 'pull-left']); ?>

			<?php echo Form::select('published', ['DRAFT' => 'Oculto','PUBLISHED' =>'Publicado'],null, ['class' => 'form-control', 'placeholder' => 'Seleccione un tipo']); ?>

		</div>
	
		<div class="form-group">
			<?php echo Form::submit('Enviar', [ 'class' => 'btn btn-primary']); ?>	
		</div>
		
		<?php echo Form::close(); ?>

	</div>
</div>			
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>