<?php $__env->startSection('title','Orders List'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-sm-12">
	<a href="#" class="btn  btn-primary pull-right">New FanPage</a><hr>
	<table class="table table-striped table-sm">
		<thead>
			<tr></tr>
				<th>ID</th>
				<th>User</th>
				<th>Delivery</th>
				<th>url</th>
				<th colspan="3">Opciones</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $fanpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fanpage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($fanpage->id); ?></td>
				<td><?php echo e($fanpage->user_id); ?></td>
				<td><?php echo e($fanpage->delivery_id); ?></td>
				<td><?php echo e($fanpage->url); ?></td>
				<td>
					<a href="<?php echo e(route('admin.fanpage.show', $fanpage->id)); ?>" class="btn  btn-primary">View</a>
				</td>
				<td>
					<a href="<?php echo e(route('admin.fanpage.edit', $fanpage->id)); ?>" class="btn  btn-warning">Edit</a>
				</td>
				<td>
					<a href="<?php echo e(route('admin.fanpage.destroy', $fanpage->id)); ?>" class="btn  btn-danger">Delete</a>
				</td>
			</tr>		
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php echo $fanpages->render(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>