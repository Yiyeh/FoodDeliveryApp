<?php $__env->startSection('title','Editar Promoción'); ?>

<?php $__env->startSection('action','- Editar Promoción'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="col-sm-11">
		<a href="<?php echo e(route('user.promotion.index')); ?>" class="btn  btn-info pull-right">Ver Promociones</a> <br><br><br>

		<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
		<?php echo Form::model($promotion, ['route' => ['user.promotion.update', $promotion->id],'method' => 'PUT']); ?>

	
		<div class="form-group">
			<?php echo Form::label('delivery', 'Delivery', ['class' => 'pull-left']); ?>

			<?php echo Form::select('delivery', $deliveries, null, [ 'class' => 'form-control', 'placeholder' => 'Elija un delivery']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('title', 'Titulo', ['class' => 'pull-left']); ?>

			<?php echo Form::text('title', null, [ 'class' => 'form-control', 'placeholder' => 'Titulo']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('photo','Imagen', ['class' => 'pull-left']); ?><br>
			<?php echo Form::file('photo', null, ['class' => 'form-control']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('description', 'Descripción de la promoción', ['class' => 'pull-left']); ?>

			<?php echo Form::textarea('description', null, [ 'class' => 'form-control', 'placeholder' => 'escriba una breve descripción']); ?>	
		</div>
		
		<div class="form-group">
			<?php echo Form::label('price','Precio', ['class' => 'pull-left']); ?>

			<?php echo Form::number('price', null, ['class' => 'form-control', 'placeholder' => 'Ejemplo 10000']); ?>

		</div>

		
		<div class="form-group">
			<?php echo Form::submit('Enviar', [ 'class' => 'btn btn-primary']); ?>	
		</div>
		
		<?php echo Form::close(); ?>

	</div>
</div>			
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>