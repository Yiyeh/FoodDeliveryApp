<?php $__env->startSection('title','Create Category'); ?>

<?php $__env->startSection('action','- Create Category'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="col-sm-11">
		<a href="<?php echo e(route('admin.category.index')); ?>" class="btn  btn-info pull-right">Show List</a> <br><br><br>

		<?php echo $__env->make('layouts._errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
		<?php echo Form::open(['route' => ['admin.category.store']]); ?>

	
		<div class="form-group">
			<?php echo Form::label('name', 'Nombre', ['class' => 'pull-left']); ?>

			<?php echo Form::text('name', null, [ 'class' => 'form-control']); ?>	
		</div>

		
	
		<div class="form-group">
			<?php echo Form::submit('Enviar', [ 'class' => 'btn btn-primary']); ?>	
		</div>
	
	
		<?php echo Form::close(); ?>

	</div>
</div>			
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>