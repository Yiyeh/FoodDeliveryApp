<?php $__env->startSection('title','Orders List'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-sm-12">
	<a href="<?php echo e(route('admin.promotion.create')); ?>" class="btn  btn-primary pull-right">New Promotion</a><hr>
	<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<table class="table table-striped table-sm">
		<thead>
			<tr></tr>
				<th>ID</th>
				<th>User</th>
				<th>Delivery</th>
				<th>Title</th>
				<th>Photo</th>
				<th>Description</th>
				<th>Price</th>
				<th colspan="3">Opciones</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($promotion->id); ?></td>
				<td><?php echo e($promotion->user->name); ?></td>
				<td><?php echo e($promotion->delivery_id); ?></td>
				<td><?php echo e($promotion->title); ?></td>
				<td><img class="img-thumbnail" src="<?php echo e($promotion->photo); ?>" width="50px" alt=""></td>
				<td><?php echo e($promotion->description); ?></td>
				<td>$<?php echo e($promotion->price); ?></td>
				<td>
					<a href="<?php echo e(route('admin.promotion.show', $promotion->id)); ?>" class="btn  btn-primary">View</a>
				</td>
				<td>
					<a href="<?php echo e(route('admin.promotion.edit', $promotion->id)); ?>" class="btn  btn-warning">Edit</a>
				</td>
				<td>
					<form action="<?php echo e(route('admin.promotion.destroy', $promotion->id)); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<input type="hidden" name="_method" value="DELETE">
						<button class="btn btn-danger">Delete</button>
					</form>
				</td>
			</tr>		
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php echo $promotions->render(); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>