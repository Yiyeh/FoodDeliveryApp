<?php $__env->startSection('title','Orders List'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-sm-11">
	<a href="<?php echo e(route('admin.comment.create')); ?>" class="btn  btn-primary pull-right">New Comment</a><hr>
	<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<table class="table table-striped table-sm">
		<thead>
			<tr></tr>
				<th>ID</th>
				<th>User</th>
				<th>Delivery</th>
				<th>Comment</th>
				<th>Score</th>
				<th colspan="3">Opciones</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($comment->id); ?></td>
				<td><?php echo e($comment->user->name); ?></td>
				<td><?php echo e($comment->delivery_id); ?></td>
				<td><?php echo e($comment->comment); ?></td>
				<td><?php echo e($comment->score); ?></td>
				<td>
					<a href="<?php echo e(route('admin.comment.show', $comment->id)); ?>" class="btn  btn-primary">View</a>
				</td>
				<td>
					<a href="<?php echo e(route('admin.comment.edit', $comment->id)); ?>" class="btn  btn-warning">Edit</a>
				</td>
				<td width="50px">	
						<form action="<?php echo e(route('admin.comment.destroy', $comment->id)); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="_method" value="DELETE">
							<button class="btn btn-danger">Delete</button>
						</form>
					</td>
			</tr>		
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php echo $comments->render(); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>