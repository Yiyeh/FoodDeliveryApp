<?php $__env->startSection('title','Create Comment'); ?>

<?php $__env->startSection('action','- Create Comment'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="col-sm-11">
		<a href="<?php echo e(route('admin.comment.index')); ?>" class="btn  btn-info pull-right">Show List</a> <br><br><br>

		<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
		<?php echo Form::open(['route' => ['admin.comment.store']]); ?>

	
		<div class="form-group">
			<?php echo Form::label('delivery', 'Delivery', ['class' => 'pull-left']); ?>

			<?php echo Form::select('delivery', $deliveries, null, [ 'class' => 'form-control', 'placeholder' => 'Elija un delivery']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('comment', 'Comentario', ['class' => 'pull-left']); ?>

			<?php echo Form::textarea('comment', null, [ 'class' => 'form-control', 'placeholder' => 'Deje su comentario']); ?>	
		</div>

		
		<div class="form-group">
			<?php echo Form::label('score','Puntos', ['class' => 'pull-left']); ?>

			<?php echo Form::number('score', null, ['class' => 'form-control', 'placeholder' => 'Max: 5']); ?>

		</div>

		
		<div class="form-group">
			<?php echo Form::submit('Enviar', [ 'class' => 'btn btn-primary']); ?>	
		</div>
		
		<?php echo Form::close(); ?>

	</div>
</div>			
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>