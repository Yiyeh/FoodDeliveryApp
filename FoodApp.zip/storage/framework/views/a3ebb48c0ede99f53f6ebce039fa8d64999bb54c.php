<?php $__env->startSection('title','FoodPlaces List'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-sm-12">
	<a href="<?php echo e(route('admin.delivery.create')); ?>" class="btn  btn-primary pull-right">New Delivery</a><hr>
	<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<table class="table  table-responsive table-striped table-sm">
		<thead>
			<tr></tr>
				<th>ID</th>
				<th>User</th>
				<th>Category</th>
				<th>Name</th>
				<th>Phone</th>
				<th>Sector</th>
				<th>Logo</th>
				<th>Commune</th>
				<th>City</th>
				<th>Premium</th>
				<th>Published</th>
				<th colspan="3">Opciones</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($delivery->id); ?></td>
				<td><?php echo e($delivery->user->name); ?></td>
				<td><?php echo e($delivery->category_id); ?></td>
				<td><?php echo e($delivery->name); ?></td>
				<td><?php echo e($delivery->phone); ?></td>
				<td><?php echo e($delivery->sector); ?></td>
				<td><img class="img-thumbnail" src="<?php echo e($delivery->logo); ?>" width="50px" alt=""></td>
				<td><?php echo e($delivery->commune); ?></td>
				<td><?php echo e($delivery->city); ?></td>
				<td><?php echo e($delivery->premium); ?></td>
				<td><?php echo e($delivery->published); ?></td>
				<td>
					<a href="<?php echo e(route('admin.delivery.show', $delivery->id)); ?>" class="btn  btn-primary">View</a>
				</td>
				<td>
					<a href="<?php echo e(route('admin.delivery.edit', $delivery->id)); ?>" class="btn  btn-warning">Edit</a>
				</td>
				<td>
					<form action="<?php echo e(route('admin.delivery.destroy', $delivery->id)); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<input type="hidden" name="_method" value="DELETE">
						<button class="btn btn-danger">Delete</button>
					</form>
				</td>
			</tr>		
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php echo $deliveries->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>