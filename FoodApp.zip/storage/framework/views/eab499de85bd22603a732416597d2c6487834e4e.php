<div class="col-sm-3">

	<div class="panel panel-default">
	  	<div class="panel-heading">
	    	<h3 class="panel-title">Categorías</h3>
	  	</div>
	  	<div class="panel-body">
	  	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<a href="<?php echo e(route('guest.category.show', $category->id)); ?>"><?php echo e($category->name); ?></a><br>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	</div>
	</div>

	<div class="panel panel-default">
	  	<div class="panel-heading">
	    	<h3 class="panel-title">Ciudades</h3>
	  	</div>
	  	<div class="panel-body">
	  	<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<a href="l/<?php echo e($city->city); ?>"><?php echo e($city->city); ?></a><br>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	</div>
	</div>		
	
</div>