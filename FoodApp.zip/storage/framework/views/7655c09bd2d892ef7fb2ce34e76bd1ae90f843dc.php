<?php $__env->startSection('title', 'delivery'); ?>


<?php $__env->startSection('content'); ?>

	<div class="container">

		<div class="row">

			
		<h1 class="page-header text-centered">Mis Deliveries Registrados</h1>
			
			<div class="col-sm-12">
				<a href="<?php echo e(route('user.delivery.create')); ?>" class="btn  btn-primary pull-right">Nuevo Delivery</a><hr>
				<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<table class="table  table-responsive table-striped table-sm">
					<thead>
						<tr></tr>
							<th>Categoria</th>
							<th>Nombre</th>
							<th>Teléfono</th>
							<th>Sector</th>
							<th>Comuna</th>
							<th>Ciudad</th>
							<th>Estado</th>
							<th colspan="3">Opciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($delivery->category_id); ?></td>
							<td><?php echo e($delivery->name); ?></td>
							<td><?php echo e($delivery->phone); ?></td>
							<td><?php echo e($delivery->sector); ?></td>
							<td><?php echo e($delivery->commune); ?></td>
							<td><?php echo e($delivery->city); ?></td>
							<td><?php echo e($delivery->published); ?></td>
							<td>
								<a href="<?php echo e(url('delivery', $delivery->id)); ?>" class="btn  btn-primary">Ver</a>
							</td>
							<td>
								<a href="<?php echo e(route('user.delivery.edit', $delivery->id)); ?>" class="btn  btn-warning">Editar</a>
							</td>
							<td>
								<form action="<?php echo e(route('user.delivery.destroy', $delivery->id)); ?>" method="POST">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" name="_method" value="DELETE">
									<button class="btn btn-danger">Eliminar</button>
								</form>
							</td>
						</tr>		
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<?php echo $deliveries->render(); ?>

			</div>
		</div><!-- row -->
	</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>