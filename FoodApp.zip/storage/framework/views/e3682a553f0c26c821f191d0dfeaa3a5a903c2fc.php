<?php $__env->startSection('title','Edit Comment'); ?>

<?php $__env->startSection('action','- Edit Comment'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="col-sm-11">
		<a href="<?php echo e(route('admin.comment.index')); ?>" class="btn  btn-info pull-right">Show List</a> <br><br><br>

		<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
		<?php echo Form::model($comment, ['route' => ['admin.comment.update', $comment->id], 'method' => 'PUT']); ?>

	
		<div class="form-group">
			<?php echo Form::label('delivery', 'Delivery', ['class' => 'pull-left']); ?>

			<?php echo Form::select('delivery', $deliveries, null, [ 'class' => 'form-control', 'placeholder' => 'Elija un delivery']); ?>	
		</div>

		<div class="form-group">
			<?php echo Form::label('comment', 'Comentario', ['class' => 'pull-left']); ?>

			<?php echo Form::textarea('comment', null, [ 'class' => 'form-control', 'placeholder' => 'Deje su comentario']); ?>	
		</div>

		
		<div class="form-group">
			<?php echo Form::label('score','Puntos', ['class' => 'pull-left']); ?>

			<?php echo Form::number('score', null, ['class' => 'form-control', 'placeholder' => 'Max: 5']); ?>

		</div>

		
		<div class="form-group">
			<?php echo Form::submit('Enviar', [ 'class' => 'btn btn-primary']); ?>	
		</div>
		
		<?php echo Form::close(); ?>

	</div>
</div>			
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>