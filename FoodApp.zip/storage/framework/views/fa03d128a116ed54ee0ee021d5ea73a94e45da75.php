<?php $__env->startSection('title','Categories List'); ?>

<?php $__env->startSection('action','- Category List'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-sm-11">
	<a href="<?php echo e(route('admin.category.create')); ?>" class="btn  btn-primary pull-right">New Category</a><hr>
	<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<table class="table table-striped table-sm">
		<thead>
			<tr></tr>
				<th>ID</th>
				<th>Name</th>
				<th>Slug</th>
				<th colspan="2">Opciones</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($category->id); ?></td>
					<td><?php echo e($category->name); ?></td>
					<td><?php echo e($category->slug); ?></td>
					<td width="50px">	
						<a href="<?php echo e(route('admin.category.edit', $category->id)); ?>" class="btn btn-warning">Edit</a>
					</td>	
					<td width="50px">	
						<form action="<?php echo e(route('admin.category.destroy', $category->id)); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="_method" value="DELETE">
							<button class="btn btn-danger">Delete</button>
						</form>
					</td>
				</tr>
		
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<?php echo $categories->render(); ?>

</div>			
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>