<?php $__env->startSection('title','Orders List'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-sm-12">
	<a href="#" class="btn  btn-primary pull-right">New Order</a><hr>
	<table class="table table-striped table-sm">
		<thead>
			<tr></tr>
				<th>ID</th>
				<th>User</th>
				<th>Delivery</th>
				<th>Body</th>
				<th>Phone</th>
				<th>Address</th>
				<th>Estado</th>
				<th colspan="3">Opciones</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($order->id); ?></td>
				<td><?php echo e($order->user_id); ?></td>
				<td><?php echo e($order->delivery_id); ?></td>
				<td><?php echo e($order->body); ?></td>
				<td><?php echo e($order->phone); ?></td>
				<td><?php echo e($order->address); ?></td>
				<td><?php echo e($order->ready); ?></td>
				<td>
					<a href="<?php echo e(route('admin.order.show', $order->id)); ?>" class="btn  btn-primary">View</a>
				</td>
				<td>
					<a href="<?php echo e(route('admin.order.edit', $order->id)); ?>" class="btn  btn-warning">Edit</a>
				</td>
				<td>
					<a href="<?php echo e(route('admin.order.destroy', $order->id)); ?>" class="btn  btn-danger">Delete</a>
				</td>
			</tr>		
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php echo $orders->render(); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>