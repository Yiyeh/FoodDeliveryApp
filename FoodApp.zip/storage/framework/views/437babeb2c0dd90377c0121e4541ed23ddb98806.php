<?php $__env->startSection('title','User List'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-sm-12">
	<a href="<?php echo e(route('admin.user.create')); ?>" class="btn  btn-primary pull-right">New User</a>
	<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<table class="table table-striped table-sm">
		<thead>
			<tr></tr>
				<th>ID</th>
				<th>Name</th>
				<th>E-Mail</th>
				<th>Premium</th>
				<th>Online</th>
				<th>Type</th>
				<th colspan="3">Opciones</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($user->id); ?></td>
				<td><?php echo e($user->name); ?></td>
				<td><?php echo e($user->email); ?></td>
				<td><?php echo e($user->premium); ?></td>
				<td><?php echo e($user->online); ?></td>
				<td><?php echo e($user->type); ?></td>
				<td>
					<a href="<?php echo e(route('admin.user.show', $user->id)); ?>" class="btn  btn-primary">View</a>
				</td>
				<td>
					<a href="<?php echo e(route('admin.user.edit', $user->id)); ?>" class="btn  btn-warning">Edit</a>
				</td>
				<td width="50px">	
					<form action="<?php echo e(route('admin.user.destroy', $user->id)); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<input type="hidden" name="_method" value="DELETE">
						<button class="btn btn-danger">Delete</button>
					</form>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php echo $users->render(); ?>

</div>			
<?php $__env->stopSection(); ?>
			
		


<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>