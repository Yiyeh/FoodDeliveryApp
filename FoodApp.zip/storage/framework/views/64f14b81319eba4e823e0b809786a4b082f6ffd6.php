<?php $__env->startSection('title','Edit Category'); ?>

<?php $__env->startSection('action','- Edit Category'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="col-sm-11">
		<a href="<?php echo e(route('admin.category.index')); ?>" class="btn  btn-info pull-right">Show List</a> <br><br><br>

		<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
		<?php echo Form::model($category, ['route' => ['admin.category.update', $category->id], 'method' => 'PUT']); ?>

	
		<div class="form-group">
			<?php echo Form::label('name', 'Nombre', ['class' => 'pull-left']); ?>

			<?php echo Form::text('name', null, [ 'class' => 'form-control']); ?>	
		</div>
		
		<div class="form-group">
			<?php echo Form::submit('Enviar', [ 'class' => 'btn btn-primary']); ?>	
		</div>
	
	
		<?php echo Form::close(); ?>

	</div>
</div>			
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>