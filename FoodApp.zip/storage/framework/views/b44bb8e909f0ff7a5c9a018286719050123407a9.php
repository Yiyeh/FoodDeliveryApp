<?php $__env->startSection('title', 'Mis Promociones'); ?>


<?php $__env->startSection('content'); ?>

	<div class="container">

		<div class="row">

			
		<h1 class="page-header text-centered">Mis Promociones Registradas</h1>
			
			<div class="col-sm-12">
				<a href="<?php echo e(route('user.promotion.create')); ?>" class="btn  btn-primary pull-right">Nueva Promoción</a><hr>
				<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<table class="table  table-responsive table-striped table-sm">
					<thead>
						<tr></tr>
							<th>Delivery</th>
							<th>Título</th>
							<th>Descripción</th>
							<th>Precio</th>
							<th colspan="3">Opciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($promotion->delivery->name); ?></td>
							<td><?php echo e($promotion->title); ?></td>
							<td><?php echo e($promotion->description); ?></td>
							<td><?php echo e($promotion->price); ?></td>
							<td>
								<a href="<?php echo e(route('user.delivery.show', $promotion->delivery->id)); ?>" class="btn  btn-primary">Ver</a>
							</td>
							<td>
								<a href="<?php echo e(route('user.promotion.edit', $promotion->id)); ?>" class="btn  btn-warning">Editar</a>
							</td>
							<td>
								<form action="<?php echo e(route('user.promotion.destroy', $promotion->id)); ?>" method="POST">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" name="_method" value="DELETE">
									<button class="btn btn-danger">Eliminar</button>
								</form>
							</td>
						</tr>		
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<?php echo $promotions->render(); ?>

			</div>
		</div><!-- row -->
	</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>