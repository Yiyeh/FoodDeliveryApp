<?php $__env->startSection('title', 'delivery'); ?>


<?php $__env->startSection('content'); ?>

	<div class="container">

		<div class="row">

			<!-- div lateral Categorias -->
			<div class="col-sm-3">

				<div class="panel panel-default">
				  	<div class="panel-heading">
				    	<h3 class="panel-title">Categorias</h3>
				  	</div>
				  	<div class="panel-body">
				  	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    	<a href="<?php echo e(route('user.category.show', $category->id)); ?>"><?php echo e($category->name); ?></a><br>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  	</div>
				</div>

				<div class="panel panel-default">
				  	<div class="panel-heading">
				    	<h3 class="panel-title">Ciudades</h3>
				  	</div>
				  	<div class="panel-body">
				  	<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    	<a href="l/<?php echo e($city->city); ?>"><?php echo e($city->city); ?></a><br>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  	</div>
				</div>		
				
			</div>

			<!-- div central -->


			
			<div class="col-sm-9">
				
				<?php if(count($deliveries)): ?>
				<?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="panel panel-default">
				 
				  	<div class="panel-heading">
				    	<h3 class="panel-title"><?php echo e($delivery->name); ?></h3>
				  	</div>
				  	<div class="panel-body">
				    	<div class="col-sm-4">
			    			<img class="img-thumbnail" src="<?php echo e($delivery->logo); ?>" width="95%">
			    		</div>
			    		<div class="col-sm-4">
			    			<span><?php echo e($delivery->short); ?> </span>
			    		</div>
						<div class="col-sm-4">
			    		<span> 
			    			<i class="fa fa-truck" aria-hidden="true"></i>  <?php echo e($delivery->sector); ?> <br> 
			    			<i class="fa fa-map-marker" aria-hidden="true"></i>  <?php echo e($delivery->city); ?> <br> 
			    			<i class="fa fa-phone" aria-hidden="true"></i><small class="text-muted">  <?php echo e($delivery->phone); ?></small>
			    		</span>
			    			<a href="<?php echo e(route('user.delivery.show', $delivery->id)); ?>" class="btn btn-sm btn-primary pull-right" >Ver Delivery</a>
			    		</div>			
				  	</div>			
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php echo $deliveries->render(); ?>

				<?php else: ?>
					<div class="well"><h1>No tenemos ningún delivery registrado en esta categoría :c </h1></div>
				<?php endif; ?>
	
			</div> <!-- col-sm-9 -->
		</div><!-- row -->
	</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>