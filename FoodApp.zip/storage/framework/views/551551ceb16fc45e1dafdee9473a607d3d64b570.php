<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>FoodApp - <?php echo $__env->yieldContent('title'); ?></title>

	<link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap3.css')); ?>" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/toastr.css')); ?>" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>" crossorigin="anonymous">

</head>
<body class="dashboard">

	<style>
		body{
			margin-right: 50px;
		}
	</style>

	<?php echo $__env->make('layouts._adminNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<h1 class="page-header text-center">Admin Panel <?php echo $__env->yieldContent('action'); ?></h1>
	
	<div class="container">	
		<div class="row">
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</div> <!-- Cierre del row -->

	<script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/bootstrap3.js')); ?>"></script>
    <script src="<?php echo e(asset('js/toastr.js')); ?>"></script>
    <script>
		$('div.alert').not('.alert-important').delay(3000).fadeOut(350);
	</script>
		
</body>
</html>